
import 'package:flutter/material.dart';
import 'package:safespace/Constants/color.dart';

TextStyle Poppins = TextStyle(fontFamily: "Poppins");
TextStyle PoppinsBold = TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.bold);
TextStyle gethelp =
    TextStyle(color: Red_color, fontFamily: 'Poppins', fontWeight: FontWeight.w800);
